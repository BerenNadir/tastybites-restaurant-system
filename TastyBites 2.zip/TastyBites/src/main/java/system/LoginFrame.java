package system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {
    private final AuthService auth = new AuthService();
    private final JTextField txtUser = new JTextField(16);
    private final JPasswordField txtPass = new JPasswordField(16);

    public LoginFrame() {
        super("TBRMS — Login");
       
        SystemState.loadIfExists();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 260);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(12, 12));

        JLabel title = new JLabel("Tasty-Bites Restaurant — Sign in", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.LINE_END;
        form.add(new JLabel("Username:"), c);
        c.gridy++;
        form.add(new JLabel("Password:"), c);

        c.gridx = 1; c.gridy = 0; c.anchor = GridBagConstraints.LINE_START;
        form.add(txtUser, c);
        c.gridy++;
        form.add(txtPass, c);

        add(form, BorderLayout.CENTER);

        JButton btnLogin = new JButton(new AbstractAction("Login") {
            @Override public void actionPerformed(ActionEvent e) { doLogin(); }
        });
        getRootPane().setDefaultButton(btnLogin);

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnLogin);
        add(south, BorderLayout.SOUTH);
    }

    private void doLogin() {
        String u = txtUser.getText().trim();
        String p = new String(txtPass.getPassword());
        User user = auth.login(u, p);
        if (user == null) {
            JOptionPane.showMessageDialog(this, "Invalid credentials.", "Login failed", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Session.set(user);
        SwingUtilities.invokeLater(() -> {
            JFrame next;
            switch (user.role) {
                case MANAGER -> next = new ManagerFrame();
                case CHEF -> next = new ChefFrame();
                case WAITER -> next = new WaiterFrame();
                default -> next = new PatronFrame();
            }
            next.setVisible(true);
            dispose();
        });
    }
}
