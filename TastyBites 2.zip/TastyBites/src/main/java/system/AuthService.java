package system;

import java.util.Collection;

public class AuthService {

    public AuthService() {
       
        SystemState.ensureSeedUsers();
    }

  
    public User login(String username, String password) {
        User u = SystemState.userMap.get(username);
        if (u == null) return null;
        return u.checkPassword(password) ? u : null;  
    }


    public Collection<User> all() {
        return SystemState.userMap.values();
    }

    public boolean addUser(String username, String password, Role role, String displayName) {
        if (username == null || username.isBlank()
                || password == null || password.isBlank()
                || role == null) return false;

        if (SystemState.userMap.containsKey(username)) return false;

        String dn = (displayName == null || displayName.isBlank()) ? username : displayName;
        SystemState.userMap.put(username, new User(username, password, role, dn));
        SystemState.saveQuietly();            
        return true;
    }

   
    public boolean updateUser(String username, String newPassword, Role newRole, String newDisplayName) {
        User cur = SystemState.userMap.get(username);
        if (cur == null) return false;

      
        if (newPassword != null && !newPassword.isBlank()) {
            cur.setPassword(newPassword);
        }
       
        if (newRole != null) {
            cur.role = newRole;
        }
      
        if (newDisplayName != null && !newDisplayName.isBlank()) {
            cur.displayName = newDisplayName;
        }

        SystemState.saveQuietly();            
        return true;
    }


    public boolean removeUser(String username) {
        User target = SystemState.userMap.get(username);
        if (target == null) return false;

        if (target.role == Role.MANAGER) {
            long managers = SystemState.userMap.values().stream()
                    .filter(u -> u.role == Role.MANAGER).count();
            if (managers <= 1) return false;  
        }

        SystemState.userMap.remove(username);
        SystemState.saveQuietly();            
        return true;
    }
}
