package system;

import java.util.ArrayList;
import java.util.List;

public class MenuCatalog {
    private final List<MenuItem> items = new ArrayList<>();
    public MenuCatalog() {
        
        items.add(new MenuItem(1, "Margherita Pizza", "Pizza", 8.50));
        items.add(new MenuItem(2, "Carbonara Pasta", "Pasta", 9.20));
        items.add(new MenuItem(3, "Lasagna", "Pasta", 10.00));
        items.add(new MenuItem(4, "Tiramisu", "Dessert", 5.50));
        items.add(new MenuItem(5, "Espresso", "Beverage", 2.50));
        items.add(new MenuItem(6, "Iced Americano", "Beverage", 3.50));
        items.add(new MenuItem(7, "Kusbasili Pide", "Kebab", 9.50));
    }
    public List<MenuItem> allItems() { return items; }
}
