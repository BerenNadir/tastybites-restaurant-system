package system;

public enum Role {
    MANAGER, CHEF, WAITER, PATRON
}
