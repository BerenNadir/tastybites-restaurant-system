package system;

public class KitchenService {
    public boolean prepareOrder(Order order) {
        order.status = "Preparing";
       
        order.status = "Ready";
        return true;
    }
}
