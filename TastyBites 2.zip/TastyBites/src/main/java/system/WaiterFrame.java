package system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;


public class WaiterFrame extends BaseFrame {

   
    private final MenuCatalog catalog = new MenuCatalog();

    
    private final DefaultTableModel pendingModel =
            new DefaultTableModel(new Object[]{"Order #","Items","Total"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private JTable tblPending;

    
    private final DefaultTableModel detailModel =
            new DefaultTableModel(new Object[]{"Item","Qty","Price","Line Total"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private JTable tblDetails;

   
    private JComboBox<MenuItem> cmbMenu;
    private JSpinner spAddQty;

    public WaiterFrame() {
        super();
        setTitle("TBRMS — Waiter Station");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setJMenuBar(buildMenuBar());

        JPanel top = headerWithBack("Waiter — Patron Orders (Confirm / Edit / Send)");
        add(top, BorderLayout.NORTH);

     
        tblPending = new JTable(pendingModel);
        tblPending.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblPending.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadSelectedOrderDetails();
        });

        
        tblDetails = new JTable(detailModel);

        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton btnRefresh = new JButton(new AbstractAction("Refresh") {
            @Override public void actionPerformed(ActionEvent e) { refreshPending(); }
        });

        JButton btnInc = new JButton(new AbstractAction("Qty +") {
            @Override public void actionPerformed(ActionEvent e) { changeQty(+1); }
        });

        JButton btnDec = new JButton(new AbstractAction("Qty -") {
            @Override public void actionPerformed(ActionEvent e) { changeQty(-1); }
        });

        JButton btnRemove = new JButton(new AbstractAction("Remove Line") {
            @Override public void actionPerformed(ActionEvent e) { removeLine(); }
        });

        JButton btnSave = new JButton(new AbstractAction("Save Changes") {
            @Override public void actionPerformed(ActionEvent e) { saveDetailEditsToOrder(); }
        });

        JButton btnSend = new JButton(new AbstractAction("Send to Kitchen") {
            @Override public void actionPerformed(ActionEvent e) { sendSelectedToKitchen(); }
        });

       
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cmbMenu = new JComboBox<>(catalog.allItems().toArray(new MenuItem[0]));
        spAddQty = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        JButton btnAddItem = new JButton(new AbstractAction("Add Item") {
            @Override public void actionPerformed(ActionEvent e) { addItemToDetails(); }
        });
        addPanel.add(new JLabel("Add:")); addPanel.add(cmbMenu);
        addPanel.add(new JLabel("Qty:")); addPanel.add(spAddQty);
        addPanel.add(btnAddItem);

        btns.add(btnRefresh);
        btns.add(new JSeparator(SwingConstants.VERTICAL));
        btns.add(btnInc); btns.add(btnDec); btns.add(btnRemove);
        btns.add(btnSave);
        btns.add(btnSend);

    
        JPanel center = new JPanel(new BorderLayout(8,8));
        center.add(new JScrollPane(tblPending), BorderLayout.CENTER);

        JPanel detailsWrap = new JPanel(new BorderLayout(6,6));
        detailsWrap.add(new JLabel("Order Details"), BorderLayout.NORTH);
        detailsWrap.add(new JScrollPane(tblDetails), BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout());
        south.add(addPanel, BorderLayout.WEST);
        south.add(btns, BorderLayout.EAST);
        detailsWrap.add(south, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, center, detailsWrap);
        split.setDividerLocation(340);
        add(split, BorderLayout.CENTER);

       
        refreshPending();
    }

    

    private Order getSelectedOrder() {
        int row = tblPending.getSelectedRow();
        if (row < 0) return null;
        int orderId = Integer.parseInt(String.valueOf(pendingModel.getValueAt(row, 0)));
        for (Order o : SystemState.pendingOrders) {
            if (o.orderId == orderId) return o;
        }
        return null;
    }

    private void refreshPending() {
        pendingModel.setRowCount(0);
        for (Order o : SystemState.pendingOrders) {
            pendingModel.addRow(new Object[]{
                    o.orderId,
                    o.itemsText(),
                    String.format("£%.2f", o.total())
            });
        }
        loadSelectedOrderDetails();
    }

    private void loadSelectedOrderDetails() {
        detailModel.setRowCount(0);
        Order o = getSelectedOrder();
        if (o == null) return;
        for (OrderItem ln : o.lines) {
            double line = ln.item.price * ln.qty;
            detailModel.addRow(new Object[]{ln.item.name, ln.qty, ln.item.price, line});
        }
    }

  

    private void changeQty(int delta) {
        int r = tblDetails.getSelectedRow();
        if (r < 0) { JOptionPane.showMessageDialog(this, "Select a line first."); return; }
        int q = Integer.parseInt(String.valueOf(detailModel.getValueAt(r, 1)));
        q = Math.max(1, q + delta);
        detailModel.setValueAt(q, r, 1);
        double price = Double.parseDouble(String.valueOf(detailModel.getValueAt(r, 2)));
        detailModel.setValueAt(price * q, r, 3);
    }

    private void removeLine() {
        int r = tblDetails.getSelectedRow();
        if (r < 0) { JOptionPane.showMessageDialog(this, "Select a line first."); return; }
        detailModel.removeRow(r);
    }

  
    private void addItemToDetails() {
        Order o = getSelectedOrder();
        if (o == null) { JOptionPane.showMessageDialog(this, "Select an order first."); return; }

        MenuItem mi = (MenuItem) cmbMenu.getSelectedItem();
        if (mi == null) return;
        int addQty = (Integer) spAddQty.getValue();

    
        int existingRow = -1;
        for (int r = 0; r < detailModel.getRowCount(); r++) {
            String name = String.valueOf(detailModel.getValueAt(r, 0));
            double price = Double.parseDouble(String.valueOf(detailModel.getValueAt(r, 2)));
            if (name.equals(mi.name) && Double.compare(price, mi.price) == 0) {
                existingRow = r; break;
            }
        }
        if (existingRow >= 0) {
            int q = Integer.parseInt(String.valueOf(detailModel.getValueAt(existingRow, 1)));
            q += addQty;
            detailModel.setValueAt(q, existingRow, 1);
            detailModel.setValueAt(mi.price * q, existingRow, 3);
        } else {
            double line = mi.price * addQty;
            detailModel.addRow(new Object[]{mi.name, addQty, mi.price, line});
        }
    }

    
    private void saveDetailEditsToOrder() {
        Order o = getSelectedOrder();
        if (o == null) { JOptionPane.showMessageDialog(this, "Select an order first."); return; }

        o.lines.clear();
        for (int r=0; r<detailModel.getRowCount(); r++) {
            String name  = String.valueOf(detailModel.getValueAt(r, 0));
            int qty      = Integer.parseInt(String.valueOf(detailModel.getValueAt(r, 1)));
            double price = Double.parseDouble(String.valueOf(detailModel.getValueAt(r, 2)));
            MenuItem mi = new MenuItem(0, name, "N/A", price);
            o.lines.add(new OrderItem(mi, qty, ""));
        }
        int sel = tblPending.getSelectedRow();
        if (sel >= 0) {
            pendingModel.setValueAt(o.itemsText(), sel, 1);
            pendingModel.setValueAt(String.format("£%.2f", o.total()), sel, 2);
        }
        SystemState.saveQuietly();
        JOptionPane.showMessageDialog(this, "Changes saved.");
    }

    private void sendSelectedToKitchen() {
        Order o = getSelectedOrder();
        if (o == null) { JOptionPane.showMessageDialog(this, "Select an order first."); return; }

        saveDetailEditsToOrder();

        SystemState.pendingOrders.remove(o);
        o.status = "Queued";
        SystemState.kitchenQueue.add(o);
        SystemState.saveQuietly();

        JOptionPane.showMessageDialog(this, "Order #" + o.orderId + " sent to kitchen.");
        refreshPending();
        detailModel.setRowCount(0);
    }
}
