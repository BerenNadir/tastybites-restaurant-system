package system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public abstract class BaseFrame extends JFrame {

    protected JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu mUser = new JMenu("User");

        String who = (Session.get()!=null
                ? Session.get().displayName + " (" + Session.get().role + ")"
                : "Guest");
        JMenuItem miWho = new JMenuItem("Signed in: " + who);
        miWho.setEnabled(false);

       
        JMenuItem miHardReset = new JMenuItem(new AbstractAction("Hard Reset State") {
            @Override public void actionPerformed(ActionEvent e) {
                int ok = JOptionPane.showConfirmDialog(
                        BaseFrame.this,
                        "This will clear all in-memory orders and bills.\nAre you sure?",
                        "Confirm Hard Reset",
                        JOptionPane.OK_CANCEL_OPTION
                );
                if (ok == JOptionPane.OK_OPTION) {
                    SystemState.hardReset();
                    JOptionPane.showMessageDialog(BaseFrame.this, "State cleared.");
                }
            }
        });

        JMenuItem miBack = new JMenuItem(new AbstractAction("Back to Login") {
            @Override public void actionPerformed(ActionEvent e) {
              
                Session.clear();
                SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
                dispose();
            }
        });

        JMenuItem miLogout = new JMenuItem(new AbstractAction("Logout") {
            @Override public void actionPerformed(ActionEvent e) {
                Session.clear();
                SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
                dispose();
            }
        });

        mUser.add(miWho);
        mUser.addSeparator();
        mUser.add(miHardReset);
        mUser.addSeparator();
        mUser.add(miBack);
        mUser.add(miLogout);
        bar.add(mUser);
        return bar;
    }

   
    protected JPanel headerWithBack(String title) {
        JPanel p = new JPanel(new BorderLayout());
        JButton back = new JButton(new AbstractAction("← Back to Login") {
            @Override public void actionPerformed(ActionEvent e) {
               
                Session.clear();
                SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
                dispose();
            }
        });
        JLabel lbl = new JLabel(title);
        lbl.setFont(lbl.getFont().deriveFont(Font.BOLD, 16f));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT));
        left.add(back);
        p.add(left, BorderLayout.WEST);

        JPanel center = new JPanel(new FlowLayout(FlowLayout.LEFT));
        center.add(lbl);
        p.add(center, BorderLayout.CENTER);
        return p;
    }
}
