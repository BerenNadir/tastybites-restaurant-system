package system;

import java.io.Serializable;

public class MenuItem implements Serializable {
    public final int id;
    public final String name;
    public final String category;
    public final double price;

    public MenuItem(int id, String name, String category, double price) {
        this.id = id; this.name = name; this.category = category; this.price = price;
    }
    @Override public String toString() { return name + " (£" + price + ")"; }
}
