package system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class PatronFrame extends BaseFrame {

    private final MenuCatalog catalog = new MenuCatalog();

    private final DefaultTableModel cartModel =
            new DefaultTableModel(new Object[]{"Item","Qty","Price","Line Total"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };

    private JTable tbl;                    // cart tablosu referansı
    private double total = 0.0;

    // UI referansları
    private JButton btnAdd, btnPlace, btnPay, btnNewOrder;
    private JButton btnInc, btnDec, btnRemove, btnClear; // <<< yeni
    private JLabel  infoLabel;

    public PatronFrame() {
        super();
        setTitle("TBRMS — Patron Kiosk");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 640);
        setLocationRelativeTo(null);
        setJMenuBar(buildMenuBar());

        // Header
        JPanel top = headerWithBack("Patron — Browse & Order / Pay");
        add(top, BorderLayout.NORTH);

        // LEFT: Menu
        JPanel left = new JPanel(new BorderLayout(6,6));
        left.add(new JLabel("Browse Menu"), BorderLayout.NORTH);
        DefaultListModel<MenuItem> menuModel = new DefaultListModel<>();
        for (MenuItem mi : catalog.allItems()) menuModel.addElement(mi);
        JList<MenuItem> lst = new JList<>(menuModel);
        left.add(new JScrollPane(lst), BorderLayout.CENTER);

        // RIGHT: Cart + info
        JPanel right = new JPanel(new BorderLayout(6,6));
        JPanel rightNorth = new JPanel(new BorderLayout());
        rightNorth.add(new JLabel("Your Cart"), BorderLayout.WEST);
        infoLabel = new JLabel("");
        infoLabel.setForeground(new Color(0, 102, 204));
        rightNorth.add(infoLabel, BorderLayout.EAST);
        right.add(rightNorth, BorderLayout.NORTH);

        tbl = new JTable(cartModel);
        right.add(new JScrollPane(tbl), BorderLayout.CENTER);

        // ACTIONS
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JSpinner qty = new JSpinner(new SpinnerNumberModel(1,1,20,1));

        btnAdd = new JButton(new AbstractAction("Add to Cart") {
            @Override public void actionPerformed(ActionEvent e) {
                MenuItem mi = lst.getSelectedValue();
                if (mi == null) return;
                int q = (Integer) qty.getValue();

                // Aynı ürün varsa miktarı birleştir
                int existingRow = -1;
                for (int r = 0; r < cartModel.getRowCount(); r++) {
                    String name = String.valueOf(cartModel.getValueAt(r,0));
                    double price = Double.parseDouble(String.valueOf(cartModel.getValueAt(r,2)));
                    if (name.equals(mi.name) && Double.compare(price, mi.price) == 0) {
                        existingRow = r; break;
                    }
                }
                if (existingRow >= 0) {
                    int curQ = Integer.parseInt(String.valueOf(cartModel.getValueAt(existingRow,1)));
                    curQ += q;
                    cartModel.setValueAt(curQ, existingRow, 1);
                    cartModel.setValueAt(mi.price * curQ, existingRow, 3);
                } else {
                    double line = mi.price * q;
                    cartModel.addRow(new Object[]{mi.name, q, mi.price, line});
                }
                recalcTotal();
            }
        });

        // --- yeni düzenleme butonları (yalnızca sipariş verilmeden önce aktif) ---
        btnInc = new JButton(new AbstractAction("Qty +") {
            @Override public void actionPerformed(ActionEvent e) {
                int r = tbl.getSelectedRow();
                if (r < 0) { JOptionPane.showMessageDialog(PatronFrame.this, "Select a line first."); return; }
                int q = Integer.parseInt(String.valueOf(cartModel.getValueAt(r,1)));
                double price = Double.parseDouble(String.valueOf(cartModel.getValueAt(r,2)));
                q++;
                cartModel.setValueAt(q, r, 1);
                cartModel.setValueAt(price * q, r, 3);
                recalcTotal();
            }
        });
        btnDec = new JButton(new AbstractAction("Qty -") {
            @Override public void actionPerformed(ActionEvent e) {
                int r = tbl.getSelectedRow();
                if (r < 0) { JOptionPane.showMessageDialog(PatronFrame.this, "Select a line first."); return; }
                int q = Integer.parseInt(String.valueOf(cartModel.getValueAt(r,1)));
                double price = Double.parseDouble(String.valueOf(cartModel.getValueAt(r,2)));
                q = Math.max(1, q - 1);
                cartModel.setValueAt(q, r, 1);
                cartModel.setValueAt(price * q, r, 3);
                recalcTotal();
            }
        });
        btnRemove = new JButton(new AbstractAction("Remove") {
            @Override public void actionPerformed(ActionEvent e) {
                int r = tbl.getSelectedRow();
                if (r < 0) { JOptionPane.showMessageDialog(PatronFrame.this, "Select a line first."); return; }
                cartModel.removeRow(r);
                recalcTotal();
            }
        });
        btnClear = new JButton(new AbstractAction("Clear Cart") {
            @Override public void actionPerformed(ActionEvent e) {
                if (cartModel.getRowCount()==0) return;
                int ok = JOptionPane.showConfirmDialog(PatronFrame.this,
                        "Clear all items from cart?", "Confirm", JOptionPane.OK_CANCEL_OPTION);
                if (ok != JOptionPane.OK_OPTION) return;
                cartModel.setRowCount(0);
                recalcTotal();
            }
        });

        btnPlace = new JButton(new AbstractAction("Place Order") {
            @Override public void actionPerformed(ActionEvent e) {
                if (cartModel.getRowCount()==0) {
                    JOptionPane.showMessageDialog(PatronFrame.this, "Cart is empty.");
                    return;
                }
                Order o = new Order((int)(System.currentTimeMillis() % 100000));
                for (int r=0; r<cartModel.getRowCount(); r++) {
                    String name  = String.valueOf(cartModel.getValueAt(r,0));
                    int    q     = Integer.parseInt(String.valueOf(cartModel.getValueAt(r,1)));
                    double price = Double.parseDouble(String.valueOf(cartModel.getValueAt(r,2)));
                    MenuItem mi = new MenuItem(0, name, "N/A", price);
                    o.lines.add(new OrderItem(mi, q, ""));
                }
                o.status = "Placed";
                SystemState.pendingOrders.add(o);

                // aktif sipariş işaretleri
                SystemState.currentOrder = o;
                SystemState.currentBill  = null;
                SystemState.isPaid = false;

                SystemState.saveQuietly();

                JOptionPane.showMessageDialog(PatronFrame.this,
                        "Order #" + o.orderId + " placed. A waiter will process it.");

                // sepeti temizleyip mevcut siparişi göster (salt-okunur)
                cartModel.setRowCount(0);
                total = 0;
                refreshExistingOrderView();
            }
        });

        btnPay = new JButton(new AbstractAction("Pay Bill") {
            @Override public void actionPerformed(ActionEvent e) {
                if (SystemState.currentBill == null && SystemState.currentOrder != null) {
                    for (int i = SystemState.bills.size()-1; i >= 0; i--) {
                        Bill b = SystemState.bills.get(i);
                        if (b.order != null && b.order.orderId == SystemState.currentOrder.orderId) {
                            SystemState.currentBill = b;
                            break;
                        }
                    }
                }
                if (SystemState.currentBill == null) {
                    JOptionPane.showMessageDialog(PatronFrame.this,
                            "No bill available yet. Please ask Manager to generate the bill.");
                    return;
                }
                if (SystemState.currentBill.paid) {
                    JOptionPane.showMessageDialog(PatronFrame.this,
                            "This bill is already paid. Thank you!");
                    return;
                }

                double due = SystemState.currentBill.amount();
                int ok = JOptionPane.showConfirmDialog(PatronFrame.this,
                        "Pay £" + String.format("%.2f", due) + " now?",
                        "Confirm Payment", JOptionPane.OK_CANCEL_OPTION);
                if (ok == JOptionPane.OK_OPTION) {
                    SystemState.currentBill.paid = true;
                    SystemState.isPaid = true;
                    SystemState.saveQuietly();
                    JOptionPane.showMessageDialog(PatronFrame.this, "Payment successful. Thank you!");
                    updateTitle();
                    refreshExistingOrderView();
                }
            }
        });

        btnNewOrder = new JButton(new AbstractAction("Start New Order") {
            @Override public void actionPerformed(ActionEvent e) {
                // ödenmeden yeni sipariş açılamaz
                if (SystemState.currentBill == null || !SystemState.currentBill.paid) {
                    JOptionPane.showMessageDialog(PatronFrame.this,
                            "Please pay the existing bill before starting a new order.");
                    return;
                }
                int ok = JOptionPane.showConfirmDialog(
                        PatronFrame.this,
                        "Start a new order? Current order/bill pointers will be cleared.",
                        "Confirm",
                        JOptionPane.OK_CANCEL_OPTION
                );
                if (ok != JOptionPane.OK_OPTION) return;

                SystemState.currentOrder = null;
                SystemState.currentBill  = null;
                SystemState.isPaid = false;
                SystemState.saveQuietly();

                cartModel.setRowCount(0);
                total = 0.0;

                setCartEditingEnabled(true);
                btnNewOrder.setVisible(false);
                infoLabel.setText("");
                updateTitle();
            }
        });
        btnNewOrder.setVisible(false);

        // actions dizilimi
        actions.add(new JLabel("Qty:")); actions.add(qty);
        actions.add(btnAdd);
        actions.add(btnInc); actions.add(btnDec); actions.add(btnRemove); actions.add(btnClear);
        actions.add(btnPlace);
        actions.add(btnPay);
        actions.add(btnNewOrder);
        right.add(actions, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        split.setDividerLocation(340);
        add(split, BorderLayout.CENTER);

        // varsa mevcut siparişi açılışta göster
        refreshExistingOrderView();
        updateTitle();
    }

    /** Sepet düzenleme butonlarını topluca aç/kapat. */
    private void setCartEditingEnabled(boolean enabled) {
        btnAdd.setEnabled(enabled);
        btnInc.setEnabled(enabled);
        btnDec.setEnabled(enabled);
        btnRemove.setEnabled(enabled);
        btnClear.setEnabled(enabled);
        btnPlace.setEnabled(enabled);
    }

    /** Sepeti tekrar hesapla ve başlığı güncelle. */
    private void recalcTotal() {
        total = 0.0;
        for (int r=0; r<cartModel.getRowCount(); r++) {
            double line = Double.parseDouble(String.valueOf(cartModel.getValueAt(r,3)));
            total += line;
        }
        updateTitle();
    }

    /** Mevcut (aktif) sipariş varsa tabloya doldurur ve “yeni sipariş” akışına kilit koyar. */
    private void refreshExistingOrderView() {
        cartModel.setRowCount(0);
        total = 0.0;

        Order o = SystemState.currentOrder;
        if (o != null && !o.lines.isEmpty()) {
            for (OrderItem ln : o.lines) {
                double line = ln.item.price * ln.qty;
                cartModel.addRow(new Object[]{ln.item.name, ln.qty, ln.item.price, line});
                total += line;
            }
            String billInfo = (SystemState.currentBill != null
                    ? (" | Bill: £" + String.format("%.2f", SystemState.currentBill.amount()) +
                       " | Paid: " + (SystemState.currentBill.paid ? "Yes" : "No"))
                    : " | Bill: (not generated)");
            infoLabel.setText("Existing order #" + o.orderId + " shown (read-only)" + billInfo);

            boolean canStartNew = (SystemState.currentBill != null && SystemState.currentBill.paid);
            setCartEditingEnabled(false);           // sepet düzenleme kilit
            btnNewOrder.setVisible(canStartNew);
        } else {
            infoLabel.setText("");
            setCartEditingEnabled(true);            // yeni sipariş süreci
            btnNewOrder.setVisible(false);
        }
        updateTitle();
    }

    private void updateTitle() {
        String billPart = (SystemState.currentBill != null)
                ? " | Bill: £" + String.format("%.2f", SystemState.currentBill.amount())
                  + " | Paid: " + (SystemState.currentBill.paid ? "Yes" : "No")
                : "";
        setTitle("TBRMS — Patron Kiosk | Total: £" + String.format("%.2f", total) + billPart);
    }
}
