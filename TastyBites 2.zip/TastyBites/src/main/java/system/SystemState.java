package system;

import java.io.*;
import java.util.*;


public class SystemState implements Serializable {


    public static final Map<String, User> userMap = new LinkedHashMap<>();

    public static void ensureSeedUsers() {
        if (!userMap.isEmpty()) return;
        addSeed(new User("manager1", "pass123", Role.MANAGER, "Maria Rossi"));
        addSeed(new User("chef1",    "pass123", Role.CHEF,    "Luca Bianchi"));
        addSeed(new User("waiter1",  "pass123", Role.WAITER,  "Giulia Verdi"));
        addSeed(new User("patron1",  "pass123", Role.PATRON,  "Alex Smith"));
    }
    private static void addSeed(User u) { userMap.put(u.username, u); }


    public static final List<Order> pendingOrders = new ArrayList<>();
    public static final List<Order> kitchenQueue  = new ArrayList<>();
    public static final List<Order> readyOrders   = new ArrayList<>();


    public static final List<Bill> bills = new ArrayList<>();

    public static final List<Ingredient> ingredients = new ArrayList<>();


    public static Order currentOrder = null;
    public static Bill  currentBill  = null;
    public static boolean isPaid     = false;

  
    public static void resetAll() {
        currentOrder = null;
        currentBill  = null;
        isPaid = false;
        saveQuietly();
    }

 
    public static void hardReset() {
        pendingOrders.clear();
        kitchenQueue.clear();
        readyOrders.clear();
        bills.clear();
        currentOrder = null;
        currentBill  = null;
        isPaid = false;
      
        saveQuietly();
    }

   
    private static String filePath() {
        String home = System.getProperty("user.home");
        return home + File.separator + ".tbrms_state.bin";
    }


    public static void saveQuietly() {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new BufferedOutputStream(new FileOutputStream(filePath())))) {

            Snapshot snap = new Snapshot();

         
            snap.pending = new ArrayList<>(pendingOrders);
            snap.queue   = new ArrayList<>(kitchenQueue);
            snap.ready   = new ArrayList<>(readyOrders);
            snap.bills   = new ArrayList<>(bills);

            
            snap.ingredients = new ArrayList<>(ingredients);

           
            snap.currentOrderId = (currentOrder == null ? -1 : currentOrder.orderId);
            snap.currentBillId  = (currentBill  == null ? -1 : currentBill.id);
            snap.isPaid = isPaid;

            
            snap.users = new ArrayList<>();
            for (User u : userMap.values()) {
                UserDTO dto = new UserDTO();
                dto.u = u.username;
                dto.p = u.getPassword();  
                dto.r = u.role.name();
                dto.d = u.displayName;
                snap.users.add(dto);
            }

            out.writeObject(snap);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public static void loadIfExists() {
        File f = new File(filePath());
        if (!f.exists()) {
            ensureSeedUsers();
            return;
        }
        try (ObjectInputStream in = new ObjectInputStream(
                new BufferedInputStream(new FileInputStream(f)))) {
            Object o = in.readObject();
            if (!(o instanceof Snapshot snap)) {
                ensureSeedUsers();
                return;
            }

       
            pendingOrders.clear(); pendingOrders.addAll(snap.pending);
            kitchenQueue.clear();  kitchenQueue.addAll(snap.queue);
            readyOrders.clear();   readyOrders.addAll(snap.ready);
            bills.clear();         bills.addAll(snap.bills);
            isPaid = snap.isPaid;

 
            ingredients.clear();
            if (snap.ingredients != null) ingredients.addAll(snap.ingredients);

        
            userMap.clear();
            if (snap.users != null) {
                for (UserDTO dto : snap.users) {
                    try {
                        Role role = Role.valueOf(dto.r);
                        userMap.put(dto.u, new User(dto.u, dto.p, role, dto.d));
                    } catch (Exception ignore) { /* role parse hatası vs */ }
                }
            }
            if (userMap.isEmpty()) ensureSeedUsers();

      
            currentOrder = null; currentBill = null;
            if (snap.currentOrderId != -1) {
                for (Order ord : pendingOrders) if (ord.orderId == snap.currentOrderId) currentOrder = ord;
                for (Order ord : kitchenQueue)  if (ord.orderId == snap.currentOrderId) currentOrder = ord;
                for (Order ord : readyOrders)   if (ord.orderId == snap.currentOrderId) currentOrder = ord;
                if (currentOrder == null) { // belki çoktan bill kesilmiştir
                    for (Bill b : bills) if (b.order != null && b.order.orderId == snap.currentOrderId) {
                        currentOrder = b.order; break;
                    }
                }
            }
            if (snap.currentBillId != -1) {
                for (Bill b : bills) if (b.id == snap.currentBillId) { currentBill = b; break; }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            if (userMap.isEmpty()) ensureSeedUsers();
        }
    }

 
    private static class Snapshot implements Serializable {
   
        List<Order> pending, queue, ready;
        List<Bill> bills;

     
        List<Ingredient> ingredients;

       
        List<UserDTO> users;

     
        int currentOrderId;
        int currentBillId;
        boolean isPaid;
    }

   
    private static class UserDTO implements Serializable {
        String u; // username
        String p; // password
        String r; // role name
        String d; // display name
    }
}
