package system;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.Objects;

public class ManagerFrame extends BaseFrame {

   
    private final DefaultTableModel staffModel =
            new DefaultTableModel(new Object[]{"Username","Display Name","Role","Password"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private JTable tblStaff;
    private JTextField txtU, txtD;
    private JPasswordField txtP;
    private JComboBox<Role> cmbR;

   
    private final DefaultTableModel salesModel =
            new DefaultTableModel(new Object[]{"Bill #","Amount","Date","Paid"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private JTable tblSales;
    private final JTextArea txtBill = new JTextArea(12, 50);

    public ManagerFrame() {
        super();
        setTitle("TBRMS — Manager Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setJMenuBar(buildMenuBar());

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Users", buildUsersTab());
        tabs.addTab("Sales & Billing", buildSalesTab());
        tabs.addTab("Print Bill", buildPrintTab());
        add(tabs);

        reloadUsersTable();
        reloadSalesTable();
    }

    
    private JPanel buildUsersTab() {
        JPanel users = new JPanel(new BorderLayout(8,8));
        users.add(headerWithBack("Manager — Manage Users"), BorderLayout.NORTH);

        tblStaff = new JTable(staffModel);
        tblStaff.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        tblStaff.getSelectionModel().addListSelectionListener(this::onSelectUser);
        users.add(new JScrollPane(tblStaff), BorderLayout.CENTER);

        JPanel south = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,6,4,6);

        c.gridy = 0; c.gridx = 0; c.anchor = GridBagConstraints.LINE_END; south.add(new JLabel("Username:"), c);
        c.gridx = 1; c.anchor = GridBagConstraints.LINE_START; txtU = new JTextField(12); south.add(txtU, c);

        c.gridy++; c.gridx = 0; c.anchor = GridBagConstraints.LINE_END; south.add(new JLabel("Display Name:"), c);
        c.gridx = 1; c.anchor = GridBagConstraints.LINE_START; txtD = new JTextField(16); south.add(txtD, c);

        c.gridy++; c.gridx = 0; c.anchor = GridBagConstraints.LINE_END; south.add(new JLabel("Role:"), c);
        c.gridx = 1; c.anchor = GridBagConstraints.LINE_START; cmbR = new JComboBox<>(Role.values()); south.add(cmbR, c);

        c.gridy++; c.gridx = 0; c.anchor = GridBagConstraints.LINE_END; south.add(new JLabel("Password:"), c);
        c.gridx = 1; c.anchor = GridBagConstraints.LINE_START; txtP = new JPasswordField(12); south.add(txtP, c);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnAdd = new JButton(new AbstractAction("Add") {
            @Override public void actionPerformed(ActionEvent e) { doAddUser(); }
        });
        JButton btnUpdate = new JButton(new AbstractAction("Update Selected") {
            @Override public void actionPerformed(ActionEvent e) { doUpdateUser(); }
        });
        JButton btnResetPw = new JButton(new AbstractAction("Set/Reset Password") {
            @Override public void actionPerformed(ActionEvent e) { doResetPassword(); }
        });
        JButton btnRemove = new JButton(new AbstractAction("Remove Selected") {
            @Override public void actionPerformed(ActionEvent e) { doRemoveUser(); }
        });
        JButton btnReload = new JButton(new AbstractAction("Reload") {
            @Override public void actionPerformed(ActionEvent e) { reloadUsersTable(); }
        });
        buttons.add(btnAdd); buttons.add(btnUpdate); buttons.add(btnResetPw); buttons.add(btnRemove); buttons.add(btnReload);

        c.gridy++; c.gridx = 0; c.gridwidth = 2; c.anchor = GridBagConstraints.LINE_END;
        south.add(buttons, c);

        users.add(south, BorderLayout.SOUTH);
        return users;
    }

    private void reloadUsersTable() {
        staffModel.setRowCount(0);
        for (User u : SystemState.userMap.values()) {
            staffModel.addRow(new Object[]{u.username, u.displayName, u.role, "••••••"});
        }
    }

   
    private void onSelectUser(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        int r = tblStaff.getSelectedRow();
        if (r < 0) return;
        String username = String.valueOf(staffModel.getValueAt(r, 0));
        User u = SystemState.userMap.get(username);
        if (u == null) return;
        txtU.setText(u.username);
        txtD.setText(u.displayName);
        cmbR.setSelectedItem(u.role);
        txtP.setText(""); // güvenlik
    }

    private void doAddUser() {
        String u = txtU.getText().trim();
        String d = txtD.getText().trim();
        String p = new String(txtP.getPassword());
        Role r = (Role) cmbR.getSelectedItem();

        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and Password are required.");
            return;
        }
        if (SystemState.userMap.containsKey(u)) {
            JOptionPane.showMessageDialog(this, "Username already exists.");
            return;
        }
        if (d.isEmpty()) d = u;

        SystemState.userMap.put(u, new User(u, p, r, d));
        SystemState.saveQuietly();
        reloadUsersTable();

        txtU.setText(""); txtD.setText(""); txtP.setText("");
        cmbR.setSelectedItem(Role.PATRON);
    }

    private void doUpdateUser() {
        int rSel = tblStaff.getSelectedRow();
        if (rSel < 0) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }

        String oldUsername = String.valueOf(staffModel.getValueAt(rSel, 0));
        User u = SystemState.userMap.get(oldUsername);
        if (u == null) return;

        String newUsername = txtU.getText().trim();
        String display = txtD.getText().trim();
        Role role = (Role) cmbR.getSelectedItem();
        if (newUsername.isEmpty()) { JOptionPane.showMessageDialog(this, "Username cannot be empty."); return; }
        if (!Objects.equals(oldUsername, newUsername) && SystemState.userMap.containsKey(newUsername)) {
            JOptionPane.showMessageDialog(this, "Username already exists.");
            return;
        }
        if (display.isEmpty()) display = newUsername;

        SystemState.userMap.remove(oldUsername);
       
        u = new User(newUsername, u.getPassword(), role, display);
        SystemState.userMap.put(newUsername, u);

        SystemState.saveQuietly();
        reloadUsersTable();

        for (int i=0;i<staffModel.getRowCount();i++) {
            if (String.valueOf(staffModel.getValueAt(i,0)).equals(newUsername)) {
                tblStaff.getSelectionModel().setSelectionInterval(i,i);
                break;
            }
        }
    }

    private void doResetPassword() {
        int rSel = tblStaff.getSelectedRow();
        if (rSel < 0) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }
        String username = String.valueOf(staffModel.getValueAt(rSel, 0));
        User u = SystemState.userMap.get(username);
        if (u == null) return;

        String p = new String(txtP.getPassword());
        if (p.isEmpty()) { JOptionPane.showMessageDialog(this, "Type a new password into the Password field first."); return; }
        u.setPassword(p); // setter kullan
        SystemState.saveQuietly();
        txtP.setText("");
        JOptionPane.showMessageDialog(this, "Password updated.");
    }

    private void doRemoveUser() {
        int rSel = tblStaff.getSelectedRow();
        if (rSel < 0) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }
        String username = String.valueOf(staffModel.getValueAt(rSel, 0));

        int ok = JOptionPane.showConfirmDialog(this,
                "Remove user '" + username + "' ?", "Confirm", JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return;

        SystemState.userMap.remove(username);
        SystemState.saveQuietly();
        reloadUsersTable();
    }

  
    private JPanel buildSalesTab() {
        JPanel sales = new JPanel(new BorderLayout(8,8));
        sales.add(headerWithBack("Manager — Sales & Billing (History)"), BorderLayout.NORTH);

        tblSales = new JTable(salesModel);
        tblSales.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblSales.getSelectionModel().addListSelectionListener(this::onSelectBill);
        sales.add(new JScrollPane(tblSales), BorderLayout.CENTER);

        JPanel billActions = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton btnSeed = new JButton(new AbstractAction("Generate Sample Report") {
            @Override public void actionPerformed(ActionEvent e) {
                salesModel.setRowCount(0);
                salesModel.addRow(new Object[]{101, 68.50, LocalDate.now().toString(), "Yes"});
                salesModel.addRow(new Object[]{102, 24.00, LocalDate.now().toString(), "No"});
                salesModel.addRow(new Object[]{103, 112.20, LocalDate.now().toString(), "Yes"});
            }
        });

        JButton btnRefresh = new JButton(new AbstractAction("Refresh") {
            @Override public void actionPerformed(ActionEvent e) { reloadSalesTable(); }
        });

        JButton btnBill = new JButton(new AbstractAction("Generate Bill for Current Order") {
            @Override public void actionPerformed(ActionEvent e) { generateBillForCurrentOrder(); }
        });

        JButton btnTogglePaid = new JButton(new AbstractAction("Mark Paid / Unpaid") {
            @Override public void actionPerformed(ActionEvent e) { togglePaid(); }
        });

        JButton btnDelete = new JButton(new AbstractAction("Delete Selected Bill") {
            @Override public void actionPerformed(ActionEvent e) { deleteSelectedBill(); }
        });

        billActions.add(btnSeed);
        billActions.add(btnRefresh);
        billActions.add(btnBill);
        billActions.add(btnTogglePaid);
        billActions.add(btnDelete);
        sales.add(billActions, BorderLayout.SOUTH);

        return sales;
    }

    private JPanel buildPrintTab() {
        JPanel billing = new JPanel(new BorderLayout(8,8));
        billing.add(headerWithBack("Manager — Print/Save Bill"), BorderLayout.NORTH);
        JButton btnPrint = new JButton(new AbstractAction("Print / Save") {
            @Override public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(ManagerFrame.this,
                        "Pretend to print/save the bill.\n(Prototype only)");
            }
        });
        txtBill.setEditable(false);
        billing.add(new JScrollPane(txtBill), BorderLayout.CENTER);
        billing.add(btnPrint, BorderLayout.SOUTH);
        return billing;
    }

    private void onSelectBill(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        int row = tblSales.getSelectedRow();
        if (row < 0) { txtBill.setText(""); return; }
        int id = Integer.parseInt(String.valueOf(salesModel.getValueAt(row,0)));
        Bill b = SystemState.bills.stream().filter(x -> x.id == id).findFirst().orElse(null);
        if (b != null) txtBill.setText(buildBillText(b));
    }

    private void reloadSalesTable() {
        salesModel.setRowCount(0);
        for (Bill b : SystemState.bills) {
            salesModel.addRow(new Object[]{b.id, b.amount(), LocalDate.now().toString(), (b.paid ? "Yes":"No")});
        }
        if (SystemState.currentBill != null) {
            selectBillInTable(SystemState.currentBill.id);
            txtBill.setText(buildBillText(SystemState.currentBill));
        } else {
            txtBill.setText("");
        }
    }

    private void selectBillInTable(int billId) {
        for (int r=0; r<salesModel.getRowCount(); r++) {
            int id = Integer.parseInt(String.valueOf(salesModel.getValueAt(r,0)));
            if (id == billId) {
                tblSales.getSelectionModel().setSelectionInterval(r, r);
                tblSales.scrollRectToVisible(tblSales.getCellRect(r,0,true));
                break;
            }
        }
    }

    private void generateBillForCurrentOrder() {
        if (SystemState.currentOrder == null) {
            JOptionPane.showMessageDialog(this, "No active order to bill.");
            return;
        }
        Bill existing = SystemState.bills.stream()
                .filter(b -> b.order != null && b.order.orderId == SystemState.currentOrder.orderId)
                .findFirst().orElse(null);
        if (existing != null) {
            JOptionPane.showMessageDialog(this, "This order already has a bill (#" + existing.id + ").");
            selectBillInTable(existing.id);
            txtBill.setText(buildBillText(existing));
            return;
        }

        Bill bill = new Bill((int)(System.currentTimeMillis()%100000), SystemState.currentOrder);
        SystemState.currentBill = bill;
        SystemState.bills.add(bill);

        salesModel.addRow(new Object[]{bill.id, bill.amount(), LocalDate.now().toString(), (bill.paid ? "Yes":"No")});
        selectBillInTable(bill.id);
        txtBill.setText(buildBillText(bill));

        JOptionPane.showMessageDialog(this,
                "Bill #" + bill.id + " generated for £" + String.format("%.2f", bill.amount()));

        SystemState.saveQuietly();
    }

    private void togglePaid() {
        int row = tblSales.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a bill first."); return; }
        int id = Integer.parseInt(String.valueOf(salesModel.getValueAt(row,0)));
        Bill b = SystemState.bills.stream().filter(x -> x.id == id).findFirst().orElse(null);
        if (b == null) return;

        b.paid = !b.paid;
        salesModel.setValueAt(b.paid ? "Yes":"No", row, 3);
        if (SystemState.currentBill != null && SystemState.currentBill.id == b.id) {
            SystemState.currentBill.paid = b.paid;
        }
        txtBill.setText(buildBillText(b));
        SystemState.isPaid = b.paid;
        SystemState.saveQuietly();
    }

    private void deleteSelectedBill() {
        int row = tblSales.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a bill first."); return; }
        int id = Integer.parseInt(String.valueOf(salesModel.getValueAt(row,0)));
        Bill b = SystemState.bills.stream().filter(x -> x.id == id).findFirst().orElse(null);
        if (b == null) return;

        int ok = JOptionPane.showConfirmDialog(this,
                "Delete bill #" + id + " ?", "Confirm", JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return;

        SystemState.bills.remove(b);
        if (SystemState.currentBill != null && SystemState.currentBill.id == id) {
            SystemState.currentBill = null;
        }
        salesModel.removeRow(row);
        txtBill.setText("");
        SystemState.saveQuietly();
    }

    private String buildBillText(Bill b) {
        StringBuilder sb = new StringBuilder();
        sb.append("Bill #").append(b.id).append("\n");
        for (OrderItem ln : b.order.lines) {
            sb.append(ln.item.name).append(" x ").append(ln.qty)
              .append("\t ").append(String.format("£%.2f", ln.item.price))
              .append("\t ").append(String.format("£%.2f", ln.lineTotal()))
              .append("\n");
        }
        sb.append("\nTotal: ").append(String.format("£%.2f", b.amount()));
        sb.append("\nPaid: ").append(b.paid ? "Yes":"No");
        return sb.toString();
    }
}
