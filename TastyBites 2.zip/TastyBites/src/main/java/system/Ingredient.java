package system;

import java.io.Serializable;

public class Ingredient implements Serializable {
    public String name;
    public int qty;
    public String unit;

    public Ingredient() {}

    public Ingredient(String name, int qty, String unit) {
        this.name = name;
        this.qty = qty;
        this.unit = unit;
    }
}
