package system;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChefFrame extends BaseFrame {
    private final DefaultTableModel ingrModel =
            new DefaultTableModel(new Object[]{"Ingredient","Stock","Unit"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final DefaultTableModel remindModel =
            new DefaultTableModel(new Object[]{"Message","Status"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final DefaultTableModel queueModel =
            new DefaultTableModel(new Object[]{"Order #","Items","Total","Status"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
    private final DefaultTableModel linesModel =
            new DefaultTableModel(new Object[]{"Item","Qty","Price","Line Total"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };

    private JTable tblQueue, tblLines, tblIngr;

    public ChefFrame() {
        super();
        setTitle("TBRMS — Chef Workspace");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 720);
        setLocationRelativeTo(null);
        setJMenuBar(buildMenuBar());

        JTabbedPane tabs = new JTabbedPane();

        
        JPanel ingr = new JPanel(new BorderLayout(8,8));
        ingr.add(headerWithBack("Chef — Manage F&B Ingredients"), BorderLayout.NORTH);
        tblIngr = new JTable(ingrModel);
        tblIngr.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ingr.add(new JScrollPane(tblIngr), BorderLayout.CENTER);

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JTextField txtName = new JTextField(12);
        JSpinner spQty     = new JSpinner(new SpinnerNumberModel(10, 0, 100000, 1));
        JTextField txtUnit = new JTextField(8);

        JButton btnAdd = new JButton(new AbstractAction("Add/Update") {
            @Override public void actionPerformed(ActionEvent e) {
                String name = txtName.getText().trim();
                String unit = txtUnit.getText().trim();
                int qty     = (Integer) spQty.getValue();
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(ChefFrame.this, "Name is required.");
                    return;
                }
               
                Ingredient existing = SystemState.ingredients.stream()
                        .filter(i -> i.name.equalsIgnoreCase(name))
                        .findFirst().orElse(null);
                if (existing != null) {
                    existing.qty  = qty;
                    existing.unit = unit;
                } else {
                    SystemState.ingredients.add(new Ingredient(name, qty, unit));
                }
                SystemState.saveQuietly();
                reloadIngredientsTable();

                txtName.setText(""); txtUnit.setText("");
                spQty.setValue(10);
            }
        });

        JButton btnLoadSel = new JButton(new AbstractAction("Load Selected") {
            @Override public void actionPerformed(ActionEvent e) {
                int r = tblIngr.getSelectedRow();
                if (r < 0) { JOptionPane.showMessageDialog(ChefFrame.this, "Select an item first."); return; }
                txtName.setText(String.valueOf(ingrModel.getValueAt(r,0)));
                spQty.setValue(Integer.parseInt(String.valueOf(ingrModel.getValueAt(r,1))));
                txtUnit.setText(String.valueOf(ingrModel.getValueAt(r,2)));
            }
        });

        JButton btnRemove = new JButton(new AbstractAction("Remove Selected") {
            @Override public void actionPerformed(ActionEvent e) {
                int r = tblIngr.getSelectedRow();
                if (r < 0) { JOptionPane.showMessageDialog(ChefFrame.this, "Select an item first."); return; }
                String name = String.valueOf(ingrModel.getValueAt(r,0));
                int ok = JOptionPane.showConfirmDialog(ChefFrame.this,
                        "Remove ingredient '" + name + "' ?", "Confirm", JOptionPane.OK_CANCEL_OPTION);
                if (ok != JOptionPane.OK_OPTION) return;

                SystemState.ingredients.removeIf(i -> i.name.equalsIgnoreCase(name));
                SystemState.saveQuietly();
                reloadIngredientsTable();
            }
        });

        south.add(new JLabel("Name:")); south.add(txtName);
        south.add(new JLabel("Qty:"));  south.add(spQty);
        south.add(new JLabel("Unit:")); south.add(txtUnit);
        south.add(btnAdd); south.add(btnLoadSel); south.add(btnRemove);
        ingr.add(south, BorderLayout.SOUTH);

    
        JPanel remind = new JPanel(new BorderLayout(8,8));
        remind.add(headerWithBack("Chef — Purchase Reminders"), BorderLayout.NORTH);
        JTable tRem = new JTable(remindModel);
        remind.add(new JScrollPane(tRem), BorderLayout.CENTER);
        JButton btnGen = new JButton(new AbstractAction("Generate Low-Stock Alerts") {
            @Override public void actionPerformed(ActionEvent e) {
                remindModel.setRowCount(0);
                // basit eşik: qty < 5
                for (Ingredient i : SystemState.ingredients) {
                    if (i.qty < 5) {
                        remindModel.addRow(new Object[]{ i.name + " low — reorder", "Sent" });
                    }
                }
                if (remindModel.getRowCount() == 0) {
                    remindModel.addRow(new Object[]{"All good — no low stock.", "Info"});
                }
                JOptionPane.showMessageDialog(ChefFrame.this,
                        "Reminders sent to Chef inbox (prototype).");
            }
        });
        remind.add(btnGen, BorderLayout.SOUTH);

      
        JPanel queue = new JPanel(new BorderLayout(8,8));
        queue.add(headerWithBack("Chef — Kitchen Queue"), BorderLayout.NORTH);

        tblQueue = new JTable(queueModel);
        tblQueue.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblQueue.getSelectionModel().addListSelectionListener(this::onSelectQueue);

        tblLines = new JTable(linesModel);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(tblQueue), new JScrollPane(tblLines));
        split.setDividerLocation(360);
        queue.add(split, BorderLayout.CENTER);

        JButton btnPrepare = new JButton(new AbstractAction("Prepare Selected Order") {
            @Override public void actionPerformed(ActionEvent e) {
                int row = tblQueue.getSelectedRow();
                if (row < 0) { JOptionPane.showMessageDialog(ChefFrame.this, "Select an order first."); return; }

                int orderId = Integer.parseInt(String.valueOf(queueModel.getValueAt(row, 0)));
                Order selected = SystemState.kitchenQueue.stream()
                        .filter(o -> o.orderId == orderId).findFirst().orElse(null);
                if (selected == null) { JOptionPane.showMessageDialog(ChefFrame.this, "Order not found."); return; }

                new KitchenService().prepareOrder(selected);
                queueModel.setValueAt(selected.status, row, 3);
                SystemState.kitchenQueue.remove(selected);
                SystemState.readyOrders.add(selected);
                SystemState.currentOrder = selected;

                JOptionPane.showMessageDialog(ChefFrame.this,
                        "Order #"+selected.orderId+" prepared and ready for patron.");

                SystemState.saveQuietly();
                refreshQueue();
                linesModel.setRowCount(0);
            }
        });
        queue.add(btnPrepare, BorderLayout.SOUTH);

        tabs.addTab("Ingredients", ingr);
        tabs.addTab("Reminders", remind);
        tabs.addTab("Kitchen Queue", queue);

        add(tabs);

      
        reloadIngredientsTable();
        refreshQueue();
    }

    private void reloadIngredientsTable() {
        ingrModel.setRowCount(0);
        for (Ingredient i : SystemState.ingredients) {
            ingrModel.addRow(new Object[]{i.name, i.qty, i.unit});
        }
    }

    private void onSelectQueue(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        int row = tblQueue.getSelectedRow();
        linesModel.setRowCount(0);
        if (row < 0) return;
        int orderId = Integer.parseInt(String.valueOf(queueModel.getValueAt(row, 0)));
        Order o = SystemState.kitchenQueue.stream().filter(x -> x.orderId == orderId).findFirst().orElse(null);
        if (o == null) return;
        for (OrderItem ln : o.lines) {
            linesModel.addRow(new Object[]{ln.item.name, ln.qty, ln.item.price, ln.lineTotal()});
        }
    }

    private void refreshQueue() {
        queueModel.setRowCount(0);
        for (Order o : SystemState.kitchenQueue) {
            queueModel.addRow(new Object[]{
                    o.orderId,
                    o.itemsText(),
                    String.format("£%.2f", o.total()),
                    o.status
            });
        }
    }
}
