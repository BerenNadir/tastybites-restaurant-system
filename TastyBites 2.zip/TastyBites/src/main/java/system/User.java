package system;

import java.io.Serializable;

public class User implements Serializable {
    public String username;
    private String password;   
    public Role role;
    public String displayName;

    public User(String username, String password, Role role, String displayName) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.displayName = displayName;
    }


    public boolean checkPassword(String raw) { return password != null && password.equals(raw); }
    public void setPassword(String newPassword) { this.password = newPassword; }
    public String getPassword() { return password; } 
}
