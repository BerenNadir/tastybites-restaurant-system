package system;

import java.io.Serializable;

public class Bill implements Serializable {
    public final int id;
    public final Order order;
    public boolean paid;

    public Bill(int id, Order order) {
        this.id = id; this.order = order;
        this.paid = false;
    }
    public double amount() { return order.total(); }
}
