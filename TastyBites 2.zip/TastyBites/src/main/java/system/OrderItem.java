package system;

import java.io.Serializable;

public class OrderItem implements Serializable {
    public final MenuItem item;
    public int qty;
    public String note;

    public OrderItem(MenuItem item, int qty, String note) {
        this.item = item; this.qty = qty; this.note = note;
    }
    public double lineTotal() { return item.price * qty; }
}
