package system;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Order implements Serializable {
    public final int orderId;
    public final List<OrderItem> lines = new ArrayList<>();
    public String status = "Placed"; // Placed → Queued → Ready

    public Order(int orderId) { this.orderId = orderId; }

    public double total() {
        return lines.stream().mapToDouble(OrderItem::lineTotal).sum();
    }

    public String itemsText() {
        StringBuilder sb = new StringBuilder();
        for (OrderItem ln : lines) {
            sb.append(ln.item.name).append(" x").append(ln.qty).append(", ");
        }
        if (sb.length() > 2) sb.setLength(sb.length() - 2);
        return sb.toString();
    }
}
